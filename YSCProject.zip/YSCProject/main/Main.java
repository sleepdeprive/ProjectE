
public class Main {
	
	public static void main(String[] args)
	{
		ShellAnimation animation = new ShellAnimation();
		AnimationFrame frame = new AnimationFrame((Animation)animation);
		frame.start();
	}

}
